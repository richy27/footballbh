<?php
$template_info['name'] = 'OTnewz';
$template_info['desc'] = 'OTnewz is a premium Pligg template with responsive layout, featured news slider, built-in social sharing, rich media auto-embedding ability using Embedly API and many other features.';
$template_info['author'] = 'OxyThemes';
$template_info['support'] = 'http://www.oxythemes.com/support/';
$template_info['version'] = '1.0RC1';
$template_info['designed_for_pligg_version'] = '2.0.0';	
?>