
+==================================================================================+
+==================================================================================+
											
OTnewz v1.0RC1
Last Modified: October 23, 2013					
										
Template URL:		http://www.oxythemes.com/products/templates/otnewz.html
Template Author: 		OxyThemes					
Author URL: 		http://www.oxythemes.com/			
									
+==================================================================================+
										
Installation Instructions:	http://www.oxythemes.com/forums/topic/13-installing-otnewz-pligg-template/
Forum Support:		http://www.oxythemes.com/forums/6-otnewz-pligg-template/
Customer Helpdesk:	https://www.oxythemes.com/index.php?app=nexus&module=support
										
+==================================================================================+
										
Copyright �2013 OxyThemes.com					
										
+==================================================================================+
+==================================================================================+